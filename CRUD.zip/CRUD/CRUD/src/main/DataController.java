package main;

import dao.DatabaseHelper;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
        
public class DataController {
    
    public static boolean dataInsert(String name,String email,String address){        
        Connection con = null;        
        String SQL = "INSERT INTO tbl_data(name,email,address) VALUES('"+name+"','"+email+"','"+address+"')";
        boolean bool = true;
        try {
            con = DatabaseHelper.getConnection();
            PreparedStatement ps = con.prepareStatement(SQL);
            int result = ps.executeUpdate();
            //System.out.println(result+" records affected");
            
            ps.close();
        } catch (Exception ex2) {
            ex2.printStackTrace();
        }
        
        finally {
            try {
                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        return bool;
    }
    
    public static boolean dataDelete(JTable table){
        boolean bool = true;
        try {            
            int row = table.getSelectedRow();
            if(row >= 0){                
               String value = (table.getModel().getValueAt(row, 0).toString()); 
               
                //System.out.println(value);               
                Connection con = null;        
                String SQL = "delete from tbl_data where id = '"+value+"'";
                
                try {
                    con = DatabaseHelper.getConnection();
                    PreparedStatement ps = con.prepareStatement(SQL);
                    ps.executeUpdate();
            
                    ps.close();
                } catch (Exception ex3) {
                    ex3.printStackTrace();
                }
            }
            else{
                System.out.println("Delete Error");
            }
            
        } catch (Exception e) {
            
        }
        return bool;
    }
    
    public static boolean dataUpdate(String name,String email,String address,String id){
        Connection con = null;        
        String SQL = "UPDATE tbl_data SET name = '"+name+"', email = '"+email+"', address = '"+address+"' WHERE id = '"+id+"'";
        boolean bool = true;
        try {
            con = DatabaseHelper.getConnection();
            PreparedStatement ps = con.prepareStatement(SQL);
            int result = ps.executeUpdate();
            //System.out.println(result+" records affected");
            
            ps.close();
        } catch (Exception ex2) {
            ex2.printStackTrace();
        }
        
        finally {
            try {
                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        return bool;
         
    }
    
    public static void dataShow(JTable table, JTextField name, JTextField email, JTextField address ,JTextField id) {
        try {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String value = (table.getModel().getValueAt(row, 0).toString());
                Connection con = null;
                String SQL = "select * from tbl_data where id = '" + value + "'";
                try {
                    con = DatabaseHelper.getConnection();
                    PreparedStatement ps = con.prepareStatement(SQL);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        id.setText(rs.getString("id"));
                        name.setText(rs.getString("name"));
                        email.setText(rs.getString("email"));
                        address.setText(rs.getString("address"));
                    }

                    ps.close();
                } catch (Exception ex4) {
                    ex4.printStackTrace();
                }
            } else {
                System.out.println("Delete Error");
            }

        } catch (Exception e) {

        }
    }
    
    public static void getAllData(JTable table){
        Connection con = null;
        String SQL = "SELECT * from tbl_data";
        
        try {
            con = DatabaseHelper.getConnection();
            PreparedStatement ps = con.prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel dm = new DefaultTableModel(0, 0);
            String s[] = new String[]{"ID","Sl NO", "Name" , "Email" , "Address"};
            dm.setColumnIdentifiers(s);
            table.setModel(dm);
            
            while (rs.next()) {  
                String id       = rs.getString("id");
                String slno     = Integer.toString(rs.getRow());                
                String name     = rs.getString("name");
                String email    = rs.getString("email");
                String address  = rs.getString("address");                
                
                Vector<String> vector = new Vector<String>();
                
                vector.add(id);
                vector.add(slno);                
                vector.add(name);
                vector.add(email);
                vector.add(address);             
                
                dm.addRow(vector);
            }
            table.getColumn("ID").setPreferredWidth(0);
            table.getColumn("ID").setMinWidth(0);
            table.getColumn("ID").setWidth(0);
            table.getColumn("ID").setMaxWidth(0);
            table.setDefaultEditor(Object.class, null);         
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        } 
        
        finally {
            try {
                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
    }
    
    public static void clear(JTextField name,JTextField email,JTextField address,JTextField id){
        name.setText("");
        email.setText("");
        address.setText("");
        id.setText("");
    }
}
